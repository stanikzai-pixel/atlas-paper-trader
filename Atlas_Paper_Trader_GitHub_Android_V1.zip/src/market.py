"""Public market feeds, network validation, fail-closed source pinning."""
from __future__ import annotations
import json,urllib.request,urllib.parse,urllib.error,time

UA='AtlasPaperTrader/1.0 research paper-only (public market data)'
class MarketError(RuntimeError): pass

def request_json(url,params):
    query=urllib.parse.urlencode(params)
    req=urllib.request.Request(url+'?'+query,headers={'User-Agent':UA,'Accept':'application/json'})
    last=None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req,timeout=18) as r:
                if r.status!=200:raise MarketError(f'HTTP {r.status}')
                return json.load(r)
        except (urllib.error.URLError,TimeoutError,ValueError,MarketError) as exc:
            last=exc
            if attempt<2:time.sleep(1+attempt)
    raise MarketError(f'Network/API error: {str(last)[:180]}')

def _bar_from_binance(x):
    return {'t':int(x[0]),'o':float(x[1]),'h':float(x[2]),'l':float(x[3]),'c':float(x[4])}

def _bar_from_bybit(x):
    return {'t':int(x[0]),'o':float(x[1]),'h':float(x[2]),'l':float(x[3]),'c':float(x[4])}

def _validate(bars, interval_ms, min_count):
    if len(bars)<min_count:raise MarketError(f'Only {len(bars)} candles; need {min_count}')
    bars=sorted(bars,key=lambda b:b['t'])
    for i,b in enumerate(bars):
        if b['o']<=0 or b['h']<b['l'] or b['c']<=0:
            raise MarketError('Invalid OHLC in feed')
        if i and b['t']-bars[i-1]['t']!=interval_ms:
            raise MarketError('Missing/duplicate market candles; refusing to trade')
    return bars

def candles(provider,symbol,interval,now_ms,start_ms=None):
    if interval not in ('1h','1m'):raise ValueError('Unsupported candle interval')
    interval_ms=3600000 if interval=='1h' else 60000
    target_limit=1000
    if provider=='binance':
        params={'symbol':symbol,'interval':interval,'limit':1500 if interval=='1h' else 1000}
        if start_ms is not None:params['startTime']=int(start_ms)
        raw=request_json('https://fapi.binance.com/fapi/v1/klines',params)
        if not isinstance(raw,list):raise MarketError('Binance non-array response')
        bars=[_bar_from_binance(x) for x in raw]
    elif provider=='bybit':
        params={'category':'linear','symbol':symbol,'interval':'60' if interval=='1h' else '1','limit':target_limit}
        if start_ms is not None:params['start']=int(start_ms)
        raw=request_json('https://api.bybit.com/v5/market/kline',params)
        if str(raw.get('retCode'))!='0':raise MarketError('Bybit returned error '+str(raw.get('retMsg'))[:80])
        bars=[_bar_from_bybit(x) for x in raw['result']['list']]
    else:raise MarketError('Unknown exchange source')
    # Exclude forming bars (strictly CLOSED only), no forward-looking info.
    bars=[b for b in bars if b['t']+interval_ms<=now_ms-10000]
    min_count=900 if interval=='1h' else 1
    bars=_validate(bars,interval_ms,min_count)
    # Old/cached data is a hard error, not a valid live paper fill.
    max_age_ms=90*60000 if interval=='1h' else 5*60000
    if now_ms-(bars[-1]['t']+interval_ms)>max_age_ms:
        raise MarketError(f'{provider} {symbol} stale {interval} candles; refusing to trade')
    return bars

def spot_price(provider,symbol):
    if provider=='binance':
        data=request_json('https://fapi.binance.com/fapi/v1/ticker/price',{'symbol':symbol})
        val=float(data['price'])
    elif provider=='bybit':
        data=request_json('https://api.bybit.com/v5/market/tickers',{'category':'linear','symbol':symbol})
        if str(data.get('retCode'))!='0':raise MarketError('Bybit ticker error')
        val=float(data['result']['list'][0]['lastPrice'])
    else:raise MarketError('Unknown source')
    if not (val>0):raise MarketError('Ticker nonpositive')
    return val

def choose_provider(current,now_ms):
    if current:
        candles(current,'BTCUSDT','1h',now_ms)
        return current
    errors=[]
    for p in ('binance','bybit'):
        try:
            candles(p,'BTCUSDT','1h',now_ms)
            return p
        except (MarketError,ValueError,KeyError,TypeError) as e:
            errors.append(p+': '+str(e)[:130])
    raise MarketError('No provider reachable; '+ ' | '.join(errors))
