import unittest
from unittest.mock import patch
from src import market,engine

class MarketTests(unittest.TestCase):
    def test_binance_ohlc_decode_and_drop_unclosed(self):
        now=1800000000000
        t=((now//3600000)-1001)*3600000
        raw=[]
        for i in range(1001):
            ts=t+i*3600000
            raw.append([ts,'100.0','101','99','100.5','1.0',ts+3600000-1])
        with patch.object(market,'request_json',return_value=raw):
            result=market.candles('binance','BTCUSDT','1h',now)
        self.assertGreaterEqual(len(result),900)
        self.assertEqual(result[0]['o'],100.)
        self.assertEqual(result[-1]['t'],t+999*3600000) # newest hour is not confirmed
    def test_fail_closed_on_missing_kline(self):
        now=1800000000000;t=(now//3600000-920)*3600000
        raw=[]
        for i in range(920):
            if i==100:continue
            ts=t+i*3600000
            raw.append([ts,'100','105','95','100','5',ts+3600000-1])
        with patch.object(market,'request_json',return_value=raw):
            with self.assertRaises(market.MarketError):
                market.candles('binance','BTCUSDT','1h',now)
    def test_provider_fallback_only_when_not_pinned(self):
        def fake(provider,*args,**kw):
            if provider=='binance':raise market.MarketError('region restriction')
            return [{'t':1800000000000}]
        with patch.object(market,'candles',side_effect=fake):
            self.assertEqual(market.choose_provider(None,1800000000000),'bybit')
            with self.assertRaises(market.MarketError):
                market.choose_provider('binance',1800000000000)
    def test_live_failure_no_account_mutation(self):
        s=engine.blank()
        with patch.object(market,'choose_provider',side_effect=market.MarketError('API blocked')):
            with self.assertRaises(market.MarketError):
                engine.live_tick(s,1800000000000)
        self.assertEqual(s['cash'],1000)
        self.assertEqual(s['trades'],[])
        self.assertEqual(s['status'],'NOT_STARTED')

if __name__=='__main__': unittest.main()
