import copy,math,unittest
from src import engine,strategy,site

START=1767225600000 # 2026-01-01 00:00 UTC

def make_hours(count=1000):
    bars=[]
    for i in range(count):
        px=50000+17*i+250*math.sin(i/20)
        bars.append({'t':START+i*3600000,'o':px-4,'h':px+60,'l':px-65,'c':px+8})
    return bars

def minute(t,px,low=None,high=None):
    return {'t':t,'o':px,'h':px+10 if high is None else high,'l':px-10 if low is None else low,'c':px}

class StrategyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.hours=make_hours()
        cls.features=strategy.calculate(cls.hours)
    def test_correct_feature_count(self):
        self.assertEqual(len(self.features),1000)
        self.assertTrue(math.isfinite(self.features[-1]['atr']))
        self.assertIn('harsi_open',self.features[-1])
        self.assertIn('new_bear_warning',self.features[-1])
    def test_no_future_leak(self):
        m=copy.deepcopy(self.hours)
        m[-1]['c']*=1.09
        m[-1]['h']*=1.09
        b=strategy.calculate(m)
        for key in ('long_signal','short_signal','harsi_open','harsi_close','atr','new_bear_warning','confirm_low','confirm_high'):
            self.assertEqual(self.features[-2][key],b[-2][key],key)
    def test_missing_hour_refused(self):
        with self.assertRaisesRegex(ValueError,'Missing'):
            strategy.calculate(self.hours[:500]+self.hours[501:])
    def test_harsi_rsi(self):
        v=strategy.rsi([100+i for i in range(40)],14)
        self.assertAlmostEqual(v[-1],100)

class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.hour=make_hours()
        cls.t=cls.hour[-1]['t']+3600000+8*60000
    def setup_market(self,state=None):
        now=self.t
        m=[minute(now-3*60000,67500),minute(now-2*60000,67500)]
        return {s:{'hour':self.hour,'minute':m,'price':67500} for s in engine.SYMBOLS}
    def test_bootstrap_no_backdated_trade(self):
        initial=engine.blank();market=self.setup_market()
        out=engine.tick(initial,self.t,market)
        self.assertEqual(out['status'],'LIVE')
        self.assertEqual(out['checks'],1)
        self.assertEqual(out['last_hour']['BTCUSDT'],self.hour[-1]['t']+3600000)
        self.assertEqual(out['trades'],[])
        self.assertIsNone(out['positions']['BTCUSDT'])
        self.assertIsNone(initial['last_hour']['BTCUSDT']) # no mutation
    def test_idempotent_same_hour(self):
        a=engine.tick(engine.blank(),self.t,self.setup_market())
        # Data after the most recently processed minute, no extra hourly close.
        now2=self.t+2*60000
        m=[minute(self.t-60000,67500),minute(self.t,67500)]
        b=engine.tick(a,now2,{s:{'hour':self.hour,'minute':m,'price':67500} for s in engine.SYMBOLS})
        self.assertEqual(b['last_hour'],a['last_hour'])
        self.assertEqual(b['trades'],[])
        self.assertEqual(b['checks'],2)
    def test_stop_and_no_repeat(self):
        st=engine.blank();st['last_prices']={'BTCUSDT':100,'ETHUSDT':200}
        self.assertTrue(engine.new_position(st,'BTCUSDT',1,100,2,self.t,st['last_prices']))
        p=st['positions']['BTCUSDT'];self.assertGreater(p['stop'],90)
        z=minute(self.t+60000,99,low=p['stop']-1,high=105)
        self.assertTrue(engine.check_stop_minute(st,'BTCUSDT',z))
        self.assertIsNone(st['positions']['BTCUSDT'])
        self.assertEqual(len(st['trades']),1)
        self.assertLess(st['trades'][0]['net_usdt'],0)
        self.assertFalse(engine.check_stop_minute(st,'BTCUSDT',z))
        self.assertEqual(len(st['trades']),1)
    def test_short_stop(self):
        st=engine.blank();st['last_prices']={'BTCUSDT':100,'ETHUSDT':200}
        self.assertTrue(engine.new_position(st,'BTCUSDT',-1,100,2,self.t,st['last_prices']))
        p=st['positions']['BTCUSDT']
        self.assertTrue(engine.check_stop_minute(st,'BTCUSDT',minute(self.t+60000,100,high=p['stop']+1)))
        self.assertEqual(len(st['trades']),1)
    def test_harsi_price_confirm_half_only(self):
        st=engine.blank();st['last_prices']={'BTCUSDT':104,'ETHUSDT':200}
        engine.new_position(st,'BTCUSDT',1,100,2,self.t,st['last_prices'])
        p=st['positions']['BTCUSDT'];original=p['qty']
        first={'close_time':self.t+3600000,'close':105,'atr':2,'long_regime_ok':True,
            'short_regime_ok':False,'new_bear_warning':True,'new_bull_warning':False,
            'confirm_low':103.,'confirm_high':110.}
        engine.manage_hour(st,'BTCUSDT',first,105,self.t+3600000,False)
        self.assertIsNotNone(st['positions']['BTCUSDT']['warning_hour'])
        later={**first,'close_time':self.t+7200000,'close':102,'new_bear_warning':False,
               'confirm_low':103.,'atr':2}
        engine.manage_hour(st,'BTCUSDT',later,102,self.t+7200000,False)
        self.assertTrue(st['positions']['BTCUSDT']['partial_done'])
        self.assertAlmostEqual(st['positions']['BTCUSDT']['qty'],original/2)
        self.assertEqual(len(st['trades']),0)
    def test_one_position_per_symbol_and_notional_cap(self):
        st=engine.blank();st['last_prices']={'BTCUSDT':100,'ETHUSDT':200}
        engine.new_position(st,'BTCUSDT',1,100,1,self.t,st['last_prices'])
        engine.new_position(st,'ETHUSDT',-1,200,1,self.t,st['last_prices'])
        self.assertLessEqual(engine.notional(st,st['last_prices']),2.0*engine.account_equity(st,st['last_prices'])+3)
    def test_json_roundtrip(self):
        import tempfile,json
        with tempfile.TemporaryDirectory() as tmp:
            st=engine.blank();path=tmp+'/state.json'
            engine.save(path,st)
            self.assertEqual(engine.load(path),st)
            view=site.render(st,tmp+'/site')
            from pathlib import Path
            self.assertEqual(json.loads(Path(tmp+'/site/data.json').read_text())['cash'],1000)
    def test_bad_minute_feed_preserves_input(self):
        st=engine.blank();st['last_minute']={s:self.t-5*60000 for s in engine.SYMBOLS}
        before=copy.deepcopy(st)
        with self.assertRaisesRegex(ValueError,'discontinuity'):
            engine.tick(st,self.t,self.setup_market())
        self.assertEqual(st,before)

if __name__=='__main__':unittest.main()
