import unittest
from unittest.mock import patch
from src import market, engine

class MarketTests(unittest.TestCase):
    def test_binance_ohlc_decode_and_drop_unclosed(self):
        now=1800000000000
        t=((now//3600000)-1001)*3600000
        raw=[[t+i*3600000,'100','101','99','100.5','1'] for i in range(1001)]
        with patch.object(market,'request_json',return_value=raw):
            result=market.candles('binance','BTCUSDT','1h',now)
        self.assertGreaterEqual(len(result),900)
        self.assertEqual(result[0]['o'],100.)
        self.assertEqual(result[-1]['t'],t+999*3600000)

    def test_gap_rejected(self):
        now=1800000000000;start=(now//3600000-920)*3600000
        raw=[]
        for i in range(920):
            if i==100:continue
            raw.append([start+i*3600000,'100','105','95','100','5'])
        with patch.object(market,'request_json',return_value=raw):
            with self.assertRaises(market.MarketError):
                market.candles('binance','BTCUSDT','1h',now)

    def test_gate_usdt_swap_hour_900_complete(self):
        now=(1800000000000//3600000)*3600000+20000+20000;start=(now//3600000-960)*3600000
        raw=[{'t':(start+i*3600000)//1000,'o':'100','h':'102','l':'98','c':'101'} for i in range(960)]
        with patch.object(market,'request_json',return_value=raw) as fn:
            got=market.candles('gate','BTCUSDT','1h',now)
            self.assertIn('BTC_USDT',str(fn.call_args))
        self.assertEqual(len(got),960)
        self.assertEqual(got[-1]['t'],start+959*3600000)

    def test_gate_minute_data_closed_stale_and_range(self):
        now=(1800000000000//60000)*60000+20000
        start=(now//60000-21)*60000
        raw=[{'t':(start+i*60000)//1000,'o':'100','h':'102','l':'98','c':'101'} for i in range(22)]
        with patch.object(market,'request_json',return_value=raw) as fn:
            got=market.candles('gate','ETHUSDT','1m',now,start_ms=start)
            self.assertIn("'from':",str(fn.call_args))
        self.assertEqual(len(got),21)
        self.assertEqual(got[0]['t'],start)

    def test_gate_ticker_is_futures_not_spot(self):
        with patch.object(market,'request_json',return_value=[{'last':'101.2'}]) as fn:
            self.assertEqual(market.spot_price('gate','ETHUSDT'),101.2)
            self.assertIn('/futures/usdt/tickers',str(fn.call_args))

    def test_okx_pagination_and_confirmation(self):
        now=(1800000000000//3600000)*3600000+20000
        start=(now//3600000-950)*3600000
        rows=[]
        for i in range(951):
            t=start+i*3600000
            rows.append([str(t),'100','102','98','101','1','1','1', '0' if t+3600000>now-10000 else '1'])
        responses=[]
        rows.reverse()
        for i in range(0,len(rows),300):responses.append({'code':'0','data':rows[i:i+300]})
        with patch.object(market,'request_json',side_effect=responses) as fn:
            got=market.candles('okx','BTCUSDT','1h',now)
            self.assertGreaterEqual(fn.call_count,4)
        self.assertEqual(len(got),950)
        self.assertEqual(got[-1]['t'],(now//3600000-1)*3600000)

    def test_provider_selection_and_pinning(self):
        def fake(p,*args,**kwargs):
            if p=='gate':raise market.MarketError('blocked')
            return [{'t':1800000000000}]
        with patch.object(market,'candles',side_effect=fake), patch.object(market,'spot_price',return_value=100.0):
            self.assertEqual(market.choose_provider(None,1800000000000),'okx')
            with self.assertRaises(market.MarketError):
                market.choose_provider('gate',1800000000000)

    def test_all_providers_fail_closed(self):
        with patch.object(market,'candles',side_effect=market.MarketError('blocked')):
            with self.assertRaisesRegex(market.MarketError,'No USDT-perpetual data provider reachable'):
                market.choose_provider(None,1800000000000)

    def test_live_failure_no_account_mutation(self):
        s=engine.blank()
        with patch.object(market,'choose_provider',side_effect=market.MarketError('blocked')):
            with self.assertRaises(market.MarketError):engine.live_tick(s,1800000000000)
        self.assertEqual(s['cash'],1000)
        self.assertEqual(s['trades'],[])
        self.assertEqual(s['status'],'NOT_STARTED')

if __name__=='__main__':unittest.main()
