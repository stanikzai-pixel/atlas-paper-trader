"""Persistent paper-only execution engine. NEVER sends order requests."""
from __future__ import annotations
import datetime as dt,json,math
from pathlib import Path
from . import market,strategy

SYMBOLS=('BTCUSDT','ETHUSDT')
CAPITAL=1000.0
RISK=0.005
LEVERAGE_CAP=2.0
FEE=0.0005
SLIP=0.0002
SIGNAL_MAX_AGE_MIN=35
MAX_MINUTE_GAP_MIN=950


def utc(ms):
    return dt.datetime.fromtimestamp(ms/1000,dt.timezone.utc).isoformat(timespec='seconds')

def blank():
    return {'version':1,'cash':CAPITAL,'provider':None,'positions':{s:None for s in SYMBOLS},
        'last_minute':{s:None for s in SYMBOLS},'last_hour':{s:None for s in SYMBOLS},
        'trades':[],'events':[],'equity_history':[],'last_checked':None,'last_success':None,
        'last_error':None,'status':'NOT_STARTED','checks':0,'last_prices':{},'warnings':[]}

def load(path):
    p=Path(path)
    if not p.exists():return blank()
    data=json.loads(p.read_text(encoding='utf8'))
    if data.get('version')!=1:raise RuntimeError('Unknown state version: refuse to overwrite state')
    if set(data.get('positions',{}))!=set(SYMBOLS):raise RuntimeError('Invalid saved positions')
    return data

def save(path,state):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf8')
    tmp.replace(p)

def event(state,t,kind,symbol='',detail=''):
    state['events'].append({'time':utc(t),'kind':kind,'symbol':symbol,'detail':str(detail)})
    state['events']=state['events'][-100:]

def account_equity(state,prices):
    net=state['cash']
    for s,p in state['positions'].items():
        if p and s in prices:
            mark=prices[s]*(1-p['side']*SLIP)
            net+=p['side']*p['qty']*(mark-p['entry'])-p['qty']*mark*FEE
    return net

def notional(state,prices):
    return sum(p['qty']*prices[s] for s,p in state['positions'].items() if p and s in prices)

def exit_piece(state,s,qty,price,now_ms,reason):
    p=state['positions'][s]
    if p is None or qty<=0 or qty>p['qty']+1e-10:raise RuntimeError('Invalid exit quantity')
    qty=min(qty,p['qty']);side=p['side']
    fill=price*(1-side*SLIP)
    gross=side*qty*(fill-p['entry'])
    fee=qty*fill*FEE
    state['cash']+=gross-fee
    p['gross']+=gross;p['exit_fees']+=fee;p['qty']=max(0.,p['qty']-qty)
    if p['qty']<1e-10:
        net=p['gross']-p['entry_fee']-p['exit_fees']
        trade={'symbol':s,'side':'LONG' if side==1 else 'SHORT','entry_utc':p['entry_utc'],
            'exit_utc':utc(now_ms),'entry_price':p['entry'],'exit_price':fill,
            'entry_qty':p['entry_qty'],'net_usdt':round(net,8),'reason':reason,
            'fees_usdt':round(p['entry_fee']+p['exit_fees'],8),
            'partial_exit':p['partial_done'],'risk_usdt':p['risk_budget']}
        state['trades'].append(trade)
        state['trades']=state['trades'][-1500:]
        state['positions'][s]=None
        event(state,now_ms,'CLOSE',s,f'{reason}; PnL {net:+.4f} USDT')
    return fill

def new_position(state,s,side,price,atr,now_ms,prices):
    equity=account_equity(state,prices)
    if not equity>0 or not atr>0:return False
    entry=price*(1+side*SLIP)
    dist=2*atr; stop=entry-side*dist
    if not stop>0:return False
    risk_budget=equity*RISK
    cost_buffer=(entry+max(stop,0.01))*(FEE+SLIP)
    available=max(0., LEVERAGE_CAP*equity-notional(state,prices))
    qty=min(risk_budget/(dist+cost_buffer),available/entry)
    if qty<=0:return False
    entry_fee=entry*qty*FEE
    state['cash']-=entry_fee
    state['positions'][s]={'side':side,'entry':entry,'entry_utc':utc(now_ms),'entry_ms':now_ms,
        'stop':stop,'initial_stop':stop,'risk_dist':dist,'risk_budget':risk_budget,
        'qty':qty,'entry_qty':qty,'entry_fee':entry_fee,'exit_fees':0.,'gross':0.,
        'bars':0,'armed':False,'warning_hour':None,'partial_done':False}
    event(state,now_ms,'OPEN',s,('LONG' if side==1 else 'SHORT')+f' {qty:.7f} @ {entry:.2f}, SL {stop:.2f}')
    return True

def check_stop_minute(state,s,minute):
    p=state['positions'][s]
    if p is None or minute['t']<p['entry_ms']:return False # avoid unknown pre-entry path within entry minute
    side=p['side'];stop=p['stop']
    hit=minute['o']<=stop or minute['l']<=stop if side==1 else minute['o']>=stop or minute['h']>=stop
    if not hit:return False
    through=minute['o']<=stop if side==1 else minute['o']>=stop
    reference=minute['o'] if through else stop
    exit_piece(state,s,p['qty'],reference,minute['t']+60000,'STOP_gap' if through else 'STOP_1m_estimate')
    return True

def manage_hour(state,s,feature,price,now_ms,allow_signal):
    p=state['positions'][s]
    exited=False
    if p:
        p['bars']+=1
        close_r=p['side']*(feature['close']-p['entry'])/p['risk_dist']
        if close_r>=1:p['armed']=True
        regime=feature['long_regime_ok'] if p['side']==1 else feature['short_regime_ok']
        if not regime:
            exit_piece(state,s,p['qty'],price,now_ms,'TREND_FLIP_4H')
            exited=True
        else:
            # Only a NEW pair of opposite HARSI candles starts a warning.
            w=p['warning_hour']
            if w is not None and p['armed'] and not p['partial_done']:
                lag=(feature['close_time']-w)//3600000
                line=feature['confirm_low'] if p['side']==1 else feature['confirm_high']
                confirmed=math.isfinite(line) and (feature['close']<line if p['side']==1 else feature['close']>line)
                if 1<=lag<=4 and confirmed:
                    exit_piece(state,s,p['entry_qty']*0.5,price,now_ms,'HARSI_PRICE_CONFIRM_HALF')
                    p=state['positions'][s]
                    if p:p['partial_done']=True
                    event(state,now_ms,'HARSI_HALF',s,'50% position closed after price confirmation')
                if lag>=4:p['warning_hour']=None
            p=state['positions'][s]
            if p and p['armed'] and not p['partial_done'] and p['warning_hour'] is None:
                fresh=feature['new_bear_warning'] if p['side']==1 else feature['new_bull_warning']
                if fresh:
                    p['warning_hour']=feature['close_time']
                    event(state,now_ms,'HARSI_WARNING',s,'Waiting for opposite price structure break within 4 candles')
            p=state['positions'][s]
            if p and math.isfinite(feature['atr']):
                proposal=feature['close']-p['side']*3*feature['atr']
                p['stop']=max(p['stop'],proposal) if p['side']==1 else min(p['stop'],proposal)
    if state['positions'][s] is None and not exited and allow_signal:
        side=1 if feature['long_signal'] else (-1 if feature['short_signal'] else 0)
        if side:
            new_position(state,s,side,price,feature['atr'],now_ms,state['last_prices'])

def tick(state,now_ms,feeds):
    """Atomic state transform with injected feed for repeatable tests.
    feeds[s]={hour:[...],minute:[...],price:float}; all candles completed.
    """
    import copy
    next_state=copy.deepcopy(state)
    next_state['last_checked']=utc(now_ms)
    next_state['checks']+=1
    data={}
    for s in SYMBOLS:
        if s not in feeds:raise ValueError(f'Missing {s} feed')
        f=feeds[s]
        hourly=f['hour'];minutes=f['minute'];price=float(f['price'])
        if price<=0:raise ValueError('Bad spot price')
        for b in hourly:
            if b['t']+3600000>now_ms:raise ValueError('Unclosed hour found')
        data[s]={'features':strategy.calculate(hourly),'minutes':minutes,'price':price}
    next_state['last_prices']={s:data[s]['price'] for s in SYMBOLS}
    warnings=[]
    # Minute stop checks are based on candle lows/highs, not on a browser running in background.
    for s in SYMBOLS:
        minutes=data[s]['minutes']; old=next_state['last_minute'][s]
        if old is not None and now_ms-old>MAX_MINUTE_GAP_MIN*60000:
            warnings.append(f'{s}: minute data gap >{MAX_MINUTE_GAP_MIN}m; no entries; exit prices unverified')
            continue
        fresh=[b for b in minutes if old is None or b['t']>old]
        if old is not None and fresh:
            if fresh[0]['t']!=old+60000:raise ValueError(f'{s} minute data discontinuity')
        for b in fresh:
            if b['t']+60000>now_ms:raise ValueError('Unclosed minute found')
            check_stop_minute(next_state,s,b)
        if fresh:next_state['last_minute'][s]=fresh[-1]['t']
    # One-hour close actions only once. On first boot, don't backdate a trade.
    for s in SYMBOLS:
        feats=data[s]['features'];f=feats[-1];prev=next_state['last_hour'][s]
        if prev is None:
            next_state['last_hour'][s]=f['close_time']
            event(next_state,now_ms,'INIT',s,'Warmup finished; signals begin at the next hourly close')
            continue
        if f['close_time']<=prev:continue
        missed=(f['close_time']-prev)//3600000
        age=(now_ms-f['close_time'])/60000
        allowed=missed==1 and age<=SIGNAL_MAX_AGE_MIN and not warnings
        if missed>1:warnings.append(f'{s}: missed {missed-1} hourly close(s); skipped stale signals')
        if age>SIGNAL_MAX_AGE_MIN:warnings.append(f'{s}: signal too old ({age:.0f} minutes); skipped entry')
        # Process only the most recent completed hourly signal, never backfill phantom fills.
        manage_hour(next_state,s,f,data[s]['price'],now_ms,allow_signal=allowed)
        next_state['last_hour'][s]=f['close_time']
    next_state['last_success']=utc(now_ms)
    next_state['status']='WARNING' if warnings else 'LIVE'
    next_state['warnings']=warnings[-8:]
    eq=account_equity(next_state,next_state['last_prices'])
    next_state['equity_history'].append({'utc':utc(now_ms),'equity':round(eq,6)})
    next_state['equity_history']=next_state['equity_history'][-500:]
    next_state['last_error']=None
    return next_state


def live_tick(state,now_ms):
    provider=market.choose_provider(state.get('provider'),now_ms)
    feeds={}
    for s in SYMBOLS:
        hours=market.candles(provider,s,'1h',now_ms)
        old=state['last_minute'][s]
        if old is None:
            start=now_ms-20*60000
        elif now_ms-old>MAX_MINUTE_GAP_MIN*60000:
            start=now_ms-20*60000 # explicitly mark unverified in tick()
        else:
            start=old+60000
        mins=market.candles(provider,s,'1m',now_ms,start_ms=start)
        mins=[m for m in mins if m['t']>=start]
        if not mins:raise market.MarketError('No recent completed 1m candles')
        feeds[s]={'hour':hours,'minute':mins,'price':market.spot_price(provider,s)}
    out=tick(state,now_ms,feeds)
    out['provider']=provider
    return out
