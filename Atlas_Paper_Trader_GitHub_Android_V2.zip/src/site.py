"""Static mobile dashboard; its Javascript is DISPLAY-ONLY (never trades)."""
import json,datetime as dt
from pathlib import Path
from .engine import account_equity

def render(state,path='site'):
    folder=Path(path);folder.mkdir(parents=True,exist_ok=True)
    equity=account_equity(state,state.get('last_prices',{}))
    realized=sum(t['net_usdt'] for t in state.get('trades',[]))
    view={'status':state['status'],'error':state.get('last_error'),
        'last_checked':state.get('last_checked'),'last_success':state.get('last_success'),
        'provider':state.get('provider'), 'warnings':state.get('warnings',[]),
        'cash':state['cash'],'equity':equity,'unrealized':equity-state['cash'],
        'realized':realized,'trades':state.get('trades',[])[-50:],
        'positions':state['positions'],'prices':state.get('last_prices',{}),
        'events':state.get('events',[])[-25:], 'checks':state.get('checks',0),
        'history':state.get('equity_history',[])[-250:]}
    (folder/'data.json').write_text(json.dumps(view,ensure_ascii=False,allow_nan=False,separators=(',',':')),encoding='utf8')
    return view
