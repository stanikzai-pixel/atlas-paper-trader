"""Read-only USDT perpetual data, validated and pinned to one venue.

Provider order: Gate Futures, OKX USDT SWAP, Binance USDT Futures, Bybit linear.
No fabricated prices, no fallback to spot markets, no provider change after pinning.
"""
from __future__ import annotations
import json, urllib.request, urllib.parse, urllib.error, time

UA = 'AtlasPaperTrader/1.1 paper-only research (read-only public market data)'
class MarketError(RuntimeError): pass


def request_json(url, params):
    query = urllib.parse.urlencode(params)
    req = urllib.request.Request(url + ('?' + query if query else ''),
                                 headers={'User-Agent': UA, 'Accept': 'application/json'})
    last = None
    for attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=14) as r:
                if r.status != 200:
                    raise MarketError(f'HTTP {r.status}')
                return json.load(r)
        except (urllib.error.URLError, TimeoutError, ValueError, MarketError) as exc:
            last = exc
            if attempt == 0: time.sleep(1)
    raise MarketError(f'Network/API error: {str(last)[:180]}')


def _bar_array(x):
    return {'t': int(x[0]), 'o': float(x[1]), 'h': float(x[2]),
            'l': float(x[3]), 'c': float(x[4])}


def _bar_gate(x):
    return {'t': int(x['t']) * 1000, 'o': float(x['o']), 'h': float(x['h']),
            'l': float(x['l']), 'c': float(x['c'])}


def _validate(bars, interval_ms, min_count):
    if len(bars) < min_count:
        raise MarketError(f'Only {len(bars)} candles; need {min_count}')
    bars = sorted(bars, key=lambda b: b['t'])
    for i, b in enumerate(bars):
        if (b['o'] <= 0 or b['c'] <= 0 or b['h'] < max(b['o'], b['c'], b['l'])
                or b['l'] > min(b['o'], b['c'])):
            raise MarketError('Invalid OHLC in feed')
        if i and b['t'] - bars[i-1]['t'] != interval_ms:
            raise MarketError('Missing/duplicate market candles; refusing to trade')
    return bars


def _gate_candles(symbol, interval, now_ms, start_ms=None):
    contract = symbol.replace('USDT', '_USDT')
    params = {'contract': contract, 'interval': interval}
    if interval == '1h':
        # 1,050 hourly bars accommodate EMA200(4h), slope and closed-bar rules.
        params['limit'] = 1050
    else:
        # Minute candles are needed only for stop reconstruction since previous run.
        params['from'] = int((start_ms or now_ms-20*60000) // 1000)
        params['to'] = int(now_ms//1000)
    data = request_json('https://api.gateio.ws/api/v4/futures/usdt/candlesticks', params)
    if not isinstance(data, list):
        raise MarketError('Gate Futures returned non-list candles')
    return [_bar_gate(x) for x in data]


def _okx_candles(symbol, interval, now_ms, start_ms=None):
    inst = symbol.replace('USDT', '-USDT-SWAP')
    step = 3600000 if interval == '1h' else 60000
    earliest = (now_ms - 1030*3600000 if interval == '1h' else
                (start_ms if start_ms is not None else now_ms - 20*60000))
    out = {}
    cursor = None
    # OKX returns up to 300 per page, newest first; after fetches OLDER bars.
    for _ in range(7):
        params = {'instId': inst, 'bar': '1H' if interval == '1h' else '1m', 'limit': '300'}
        if cursor is not None: params['after'] = str(cursor)
        data = request_json('https://www.okx.com/api/v5/market/candles', params)
        if not isinstance(data, dict) or str(data.get('code')) != '0':
            raise MarketError('OKX returned error: ' + str(getattr(data, 'get', lambda _ : data)('msg'))[:100])
        rows = data.get('data') or []
        if not rows: break
        oldest = min(int(r[0]) for r in rows)
        if cursor is not None and oldest >= cursor:
            raise MarketError('OKX cursor did not progress')
        for r in rows:
            # OKX confirmed candle flag: 1=closed, 0=current.
            if len(r) < 9 or str(r[8]) == '1':
                b = _bar_array(r)
                out[b['t']] = b
        if oldest <= earliest or len(rows) < 300: break
        cursor = oldest
    bars = list(out.values())
    # Avoid unrelated earlier history in a minute stop window.
    if start_ms is not None and interval == '1m':
        bars = [b for b in bars if b['t'] >= start_ms]
    return bars


def candles(provider, symbol, interval, now_ms, start_ms=None):
    if interval not in ('1h', '1m'):
        raise ValueError('Unsupported interval')
    if symbol not in ('BTCUSDT','ETHUSDT'):
        raise ValueError('Unsupported symbol')
    interval_ms = 3600000 if interval == '1h' else 60000
    if provider == 'gate':
        bars = _gate_candles(symbol, interval, now_ms, start_ms)
    elif provider == 'okx':
        bars = _okx_candles(symbol, interval, now_ms, start_ms)
    elif provider == 'binance':
        params = {'symbol': symbol, 'interval': interval,
                  'limit': 1500 if interval == '1h' else 1000}
        if start_ms is not None: params['startTime'] = int(start_ms)
        raw = request_json('https://fapi.binance.com/fapi/v1/klines', params)
        if not isinstance(raw, list): raise MarketError('Binance non-array response')
        bars = [_bar_array(x) for x in raw]
    elif provider == 'bybit':
        params = {'category':'linear','symbol':symbol,
                  'interval':'60' if interval=='1h' else '1', 'limit':1000}
        if start_ms is not None: params['start'] = int(start_ms)
        raw = request_json('https://api.bybit.com/v5/market/kline', params)
        if str(raw.get('retCode'))!='0': raise MarketError('Bybit error: '+str(raw.get('retMsg'))[:80])
        bars = [_bar_array(x) for x in raw['result']['list']]
    else:
        raise MarketError('Unknown exchange source')
    # Use fully closed candles only; never an in-progress OHLC.
    bars = [b for b in bars if b['t']+interval_ms <= now_ms-10000]
    bars = _validate(bars, interval_ms, 900 if interval=='1h' else 1)
    max_age_ms = 90*60000 if interval=='1h' else 5*60000
    if now_ms-(bars[-1]['t']+interval_ms) > max_age_ms:
        raise MarketError(f'{provider} {symbol}: stale {interval} feed; refusing to trade')
    if start_ms is not None and interval=='1m' and bars[0]['t'] > start_ms+60000:
        raise MarketError(f'{provider} {symbol}: missing older minute bars; refusing to trade')
    return bars


def spot_price(provider,symbol):
    if provider=='gate':
        raw=request_json('https://api.gateio.ws/api/v4/futures/usdt/tickers',
                         {'contract':symbol.replace('USDT','_USDT')})
        val=float(raw[0]['last'])
    elif provider=='okx':
        raw=request_json('https://www.okx.com/api/v5/market/ticker',
                         {'instId':symbol.replace('USDT','-USDT-SWAP')})
        if str(raw.get('code'))!='0':raise MarketError('OKX ticker error')
        val=float(raw['data'][0]['last'])
    elif provider=='binance':
        raw=request_json('https://fapi.binance.com/fapi/v1/ticker/price',{'symbol':symbol})
        val=float(raw['price'])
    elif provider=='bybit':
        raw=request_json('https://api.bybit.com/v5/market/tickers',{'category':'linear','symbol':symbol})
        if str(raw.get('retCode'))!='0':raise MarketError('Bybit ticker error')
        val=float(raw['result']['list'][0]['lastPrice'])
    else:
        raise MarketError('Unknown source')
    if not val>0:raise MarketError('Invalid futures ticker price')
    return val


def choose_provider(current, now_ms):
    if current:
        # NO silent venue switching after we have established a demo account.
        candles(current,'BTCUSDT','1h',now_ms)
        return current
    errors=[]
    for provider in ('gate','okx','binance','bybit'):
        try:
            # Validate BOTH symbols, 1h + 1m feeds and ticker BEFORE pinning venue.
            # This prevents choosing a provider that serves BTC but blocks ETH/minutes.
            for symbol in ('BTCUSDT','ETHUSDT'):
                candles(provider,symbol,'1h',now_ms)
                candles(provider,symbol,'1m',now_ms,start_ms=now_ms-20*60000)
                spot_price(provider,symbol)
            return provider
        except (MarketError,ValueError,KeyError,TypeError,IndexError) as e:
            errors.append(provider+': '+str(e)[:105])
    raise MarketError('No USDT-perpetual data provider reachable; '+' | '.join(errors))
