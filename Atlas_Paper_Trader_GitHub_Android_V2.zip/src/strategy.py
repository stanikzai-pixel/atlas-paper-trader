"""Atlas V2 ALL + HARSI warning and price confirmation.
All features only use already-closed 1h/4h candles; no network or trade execution.
Times are Unix milliseconds for the OPEN of an hourly candle, in UTC.
"""
from __future__ import annotations
import math
from typing import Dict, List

NAN = float('nan')

def finite(x):
    return x is not None and math.isfinite(x)

def rma(xs, n):
    """Pandas ewm(alpha=1/n, adjust=False, min_periods=n) for finite prefix."""
    out=[]; prev=None; count=0
    for x in xs:
        if finite(x):
            prev = x if prev is None else (prev * (n-1) + x)/n
            count += 1
            out.append(prev if count >= n else NAN)
        else:
            out.append(NAN)
    return out

def rsi(xs, n=14):
    """Wilder RSI with first average over the first n changes; same as Atlas HARSI research script."""
    result=[NAN]*len(xs)
    if len(xs) <= n: return result
    diffs=[xs[i]-xs[i-1] for i in range(1,len(xs))]
    gains=[max(0.,d) for d in diffs]
    losses=[max(0.,-d) for d in diffs]
    ag=sum(gains[:n])/n; al=sum(losses[:n])/n
    for i in range(n,len(xs)):
        if i>n:
            ag=(ag*(n-1)+gains[i-1])/n
            al=(al*(n-1)+losses[i-1])/n
        if al==0 and ag==0: v=50.
        elif al==0: v=100.
        elif ag==0: v=0.
        else: v=100-100/(1+ag/al)
        result[i]=v
    return result

def calculate(bars: List[dict]):
    """Return features, one per closed UTC hourly candle (bars are sorted, contiguous)."""
    if len(bars)<900:
        raise ValueError(f"Need >=900 completed hourly candles, received {len(bars)}")
    for i, b in enumerate(bars):
        if b['t']%3600000:
            raise ValueError('Kline timestamp is not UTC-hour aligned')
        if i and b['t']-bars[i-1]['t']!=3600000:
            raise ValueError('Missing or duplicated hourly candle: abort, no estimated trades')
        if b['l']>b['h'] or b['c']<=0 or b['o']<=0:
            raise ValueError('Bad hourly candle')
    n=len(bars)
    highs=[x['h'] for x in bars]; lows=[x['l'] for x in bars]; closes=[x['c'] for x in bars]
    tr=[max(highs[i]-lows[i],abs(highs[i]-closes[i-1]),abs(lows[i]-closes[i-1])) if i else highs[0]-lows[0] for i in range(n)]
    atr=rma(tr,14)
    plus_dm=[0.]*n;minus_dm=[0.]*n
    for i in range(1,n):
        up=highs[i]-highs[i-1]; dn=lows[i-1]-lows[i]
        plus_dm[i]=up if up>dn and up>0 else 0.
        minus_dm[i]=dn if dn>up and dn>0 else 0.
    plus_w=rma(plus_dm,14); minus_w=rma(minus_dm,14)
    dx=[]
    for i in range(n):
        if not finite(atr[i]) or atr[i]<=0 or not finite(plus_w[i]):dx.append(NAN);continue
        plus=plus_w[i]/atr[i];minus=minus_w[i]/atr[i]
        dx.append(100*abs(plus-minus)/(plus+minus) if plus+minus>0 else NAN)
    adx=rma(dx,14)
    # Require complete groups of 4 one-hour candles in UTC; first incomplete group ignored.
    ema4h={}; prev=None; count=0; ema_history=[]
    groups={}
    for i,b in enumerate(bars):
        group=(b['t']//14400000)*14400000
        groups.setdefault(group,[]).append((i,b))
    for group,items in sorted(groups.items()):
        if len(items)!=4 or [b['t'] for _,b in items]!=[group+j*3600000 for j in range(4)]:
            continue
        c=items[-1][1]['c']; prev = c if prev is None else prev*199/201+c*2/201
        count += 1
        ema_history.append(prev if count>=200 else NAN)
        j=len(ema_history)-1
        ema4h[group+14400000]={'close':c,'ema':ema_history[j],
            'ema_before':ema_history[j-6] if j>=6 else NAN}
    sorted4=sorted(ema4h)
    last4=None; pos4=0
    # HARSI high low close and open, with user-provided JayRogers Pine formula.
    z_close=[v-50 if finite(v) else NAN for v in rsi(closes,14)]
    z_high=[v-50 if finite(v) else NAN for v in rsi(highs,14)]
    z_low=[v-50 if finite(v) else NAN for v in rsi(lows,14)]
    ho=[NAN]*n; hc=[NAN]*n
    for i in range(n):
        if not all(finite(x) for x in (z_close[i],z_high[i],z_low[i])):continue
        ro=z_close[i-1] if i and finite(z_close[i-1]) else z_close[i]
        hc[i]=(ro+max(z_high[i],z_low[i])+min(z_high[i],z_low[i])+z_close[i])/4
        ho[i]=(ro+z_close[i])/2 if i==0 or not finite(ho[i-1]) else (ho[i-1]+hc[i-1])/2
    features=[]; prev_bear_pair=False;prev_bull_pair=False
    for i,b in enumerate(bars):
        closed=b['t']+3600000
        while pos4<len(sorted4) and sorted4[pos4]<=closed:
            last4=ema4h[sorted4[pos4]];pos4+=1
        healthy=last4 and finite(last4['ema']) and finite(last4['ema_before'])
        long_trend=bool(healthy and last4['close']>last4['ema'] and last4['ema']>last4['ema_before'])
        short_trend=bool(healthy and last4['close']<last4['ema'] and last4['ema']<last4['ema_before'])
        p_hi=max(highs[i-24:i]) if i>=24 else NAN
        p_lo=min(lows[i-24:i]) if i>=24 else NAN
        a=atr[i]
        filt=finite(a) and a>0 and finite(adx[i]) and adx[i]>=22 and a/closes[i]>=0.004
        long_signal=bool(long_trend and filt and closes[i]>p_hi+0.25*a)
        short_signal=bool(short_trend and filt and closes[i]<p_lo-0.25*a)
        bear_pair=bool(i and finite(hc[i]) and finite(ho[i]) and finite(hc[i-1]) and finite(ho[i-1]) and hc[i]<ho[i] and hc[i-1]<ho[i-1])
        bull_pair=bool(i and finite(hc[i]) and finite(ho[i]) and finite(hc[i-1]) and finite(ho[i-1]) and hc[i]>ho[i] and hc[i-1]>ho[i-1])
        features.append({'t':b['t'],'close_time':closed,'close':closes[i],'atr':a,
            'long_signal':long_signal,'short_signal':short_signal,
            'long_regime_ok':bool(last4 and finite(last4['ema']) and last4['close']>=last4['ema']),
            'short_regime_ok':bool(last4 and finite(last4['ema']) and last4['close']<=last4['ema']),
            'new_bear_warning':bear_pair and not prev_bear_pair,
            'new_bull_warning':bull_pair and not prev_bull_pair,
            'confirm_low':min(lows[i-6:i]) if i>=6 else NAN,
            'confirm_high':max(highs[i-6:i]) if i>=6 else NAN,
            'harsi_open':ho[i],'harsi_close':hc[i]})
        prev_bear_pair=bear_pair;prev_bull_pair=bull_pair
    return features
