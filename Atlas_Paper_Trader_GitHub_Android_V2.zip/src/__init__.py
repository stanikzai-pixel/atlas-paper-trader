"""Atlas paper-only market monitor."""
